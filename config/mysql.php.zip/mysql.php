<?php

ini_set('date.timezone', 'America/Santiago');

error_reporting(0);

class Mysql {

	private $host = "localhost";
	private $user = "root";
	private $pass = "root";
	private $db	  = "tesis";

	public function conexion() {


			$mysqli = new mysqli($this->host, $this->user, $this->pass, $this->db);

			$mysqli->set_charset("utf8");

			if($mysqli) {
				return $mysqli;
			}
			else {
				return $mysqli->error();
		   }
	 }
	public function get_name_equipo($id){
			$sql =mysqli_query($this->conexion(), "SELECT * FROM equipo WHERE id_equipo='".$id."'");
			$rs=mysqli_fetch_array($sql,MYSQLI_ASSOC);
			return $rs['nombre_equipo'];
		}

	public function get_type_falla($id){
			$sql =mysqli_query($this->conexion(), "SELECT * FROM tipo_falla WHERE id_tipo_falla='".$id."'");
			$rs=mysqli_fetch_array($sql,MYSQLI_ASSOC);
			$nombre = "";

			if($rs['nombre_tipo_falla'] == 'Emergencia'){
				$nombre = '<span style="margin-top:5px;" class="label label-warning col-md-10">Emergencia</span>';
			}
			else if($rs['nombre_tipo_falla'] == 'Urgente'){
				$nombre = '<span style="margin-top:5px;" class="label label-danger col-md-10">Urgente</span>';
			}
			else {
				$nombre = '<span style="margin-top:5px;" class="label label-info col-md-10">Planificada</span>';
			}

			return $nombre;
		}
		
	public function get_areas() {

		$result = null;

		$sql = mysqli_query($this->conexion(), "SELECT * FROM area WHERE area_status ='Habilitado'");
			
		while($row = mysqli_fetch_array($sql,MYSQLI_ASSOC)) {
				$result = $result.'<option value="'.$row['id_area'].'">'.$row['nombre_area'].'</option>';
		}

		return $result;
	}

	public function listar_maquina() {
			$result = null;
			$sql = mysqli_query($this->conexion(), "SELECT * FROM maquina WHERE maquina_status = 'Habilitado'");
			while($rs=mysqli_fetch_array($sql,MYSQLI_ASSOC)){
				$result = $result.'<option value="'.$rs['id_maquina'].'">'.$rs['nombre_maquina'].'</option>';;
			}
			return $result;
		}

	public function ListarEquipos() {
			$result = null;
			$sql = mysqli_query($this->conexion(),"SELECT * FROM equipo WHERE equipo_status='Habilitado'");
			while($rs=mysqli_fetch_array($sql,MYSQLI_ASSOC)){
				$result = $result.'<option value="'.$rs['id_equipo'].'">'.$rs['nombre_equipo'].'</option>';
			}
			return $result;
		}
	public function listar_fallas_tipo($tipo_falla) {
			$sql = mysqli_query($this->conexion(), "SELECT * FROM falla WHERE tipo_falla = '".$tipo_falla."'");
			$i=1;
			$result = "";
			while ($rs=mysqli_fetch_array($sql,MYSQLI_ASSOC)) {
			$result = $result.'<tr>';
			$result = $result.'<td>'.$i++.'</td>';
			$result = $result.'<td>'.$this->get_name_equipo($rs['id_equipo']).'</td>';
		 	$result = $result.'<td>'.$this->get_type_falla($rs['tipo_falla']).'</td>';
		 	$result = $result.'<td>'.$rs['fecha_falla'].'</td>';
			$result = $result.'<td><textarea readonly>'.$rs['falla_1'].'</textarea></td>';
			$result = $result.'<td><textarea readonly>'.$rs['falla_2'].'</textarea></td>';
			$result = $result.'</tr>';
			}
	 	return $result;
	}
}

?>